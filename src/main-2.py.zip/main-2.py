import random

random_number=random.randint(1,100)
for i in range(1):
  test =int(input("Guess Number:"))
  if test == random_number:
    print("You Won")
    set x== True
   if test<random_number:
      print("Nope, the number is lower")
    if test>random_number: 
    import random

random_number=random.randint(1,100)


